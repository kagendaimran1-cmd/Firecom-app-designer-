console.log("Web2APK test JS loaded!");
alert("Test JS loaded successfully!");
